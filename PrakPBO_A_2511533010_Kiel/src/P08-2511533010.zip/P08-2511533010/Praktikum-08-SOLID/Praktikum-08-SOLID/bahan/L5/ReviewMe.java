package review;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * L5 Code review. Baca setiap POTONG, lalu isi tabel di LK:
 * prinsip yang dilanggar (atau "sudah baik"), dampaknya, dan sketsa perbaikan.
 * File ini tidak perlu dijalankan, cukup dibaca (tetapi bisa dikompilasi).
 */
public class ReviewMe {

    // ===================== POTONG 1 =====================
    static class SalesReport {
        private final List<Long> sales = new ArrayList<>();

        void add(long amount) { sales.add(amount); }

        long total() { return sales.stream().mapToLong(Long::longValue).sum(); }
    }

    interface SalesRepository {
        void saveCsv(Path file, long total) throws IOException;
    }

    static class CsvSalesRepository implements SalesRepository {
        @Override
        public void saveCsv(Path file, long total) throws IOException {
            Files.writeString(file, "total;" + total);
        }
    }

    static class OwnerEmailNotifier {
        void notifyOwner(String address, long total) {
            System.out.println("Kirim email ke " + address + ": total " + total);
        }
    }

    static class SalesReportService {
        private final SalesRepository repository;
        private final OwnerEmailNotifier notifier;

        SalesReportService(SalesRepository repository, OwnerEmailNotifier notifier) {
            this.repository = repository;
            this.notifier = notifier;
        }

        void publish(SalesReport report, Path file, String address) throws IOException {
            long total = report.total();
            repository.saveCsv(file, total);
            notifier.notifyOwner(address, total);
        }
    }

    // ===================== POTONG 2 =====================
    interface ShippingRate {
        long cost(int kg);
    }

    static class JneRate implements ShippingRate {
        @Override
        public long cost(int kg) { return kg * 9_000L; }
    }

    static class JntRate implements ShippingRate {
        @Override
        public long cost(int kg) { return kg * 8_500L; }
    }

    static class SiCepatRate implements ShippingRate {
        @Override
        public long cost(int kg) { return 5_000L + kg * 7_000L; }
    }

    static class ShippingCostCalculator {
        private final ShippingRate rate;

        ShippingCostCalculator(ShippingRate rate) {
            this.rate = rate;
        }

        long cost(int kg) {
            return rate.cost(kg);
        }
    }

    // ===================== POTONG 3 =====================
    interface Cart {
        List<String> items();

        int size();
    }

    static class MutableCart implements Cart {
        private final List<String> items = new ArrayList<>();

        void addItem(String sku) { items.add(sku); }

        @Override
        public int size() { return items.size(); }

        @Override
        public List<String> items() { return List.copyOf(items); }
    }

    /** Keranjang milik pesanan yang sudah dibayar: tidak boleh diubah lagi. */
    static class ReadOnlyCart implements Cart {
        private final List<String> items;

        ReadOnlyCart(List<String> items) {
            this.items = List.copyOf(items);
        }

        @Override
        public List<String> items() { return items; }

        @Override
        public int size() { return items.size(); }
    }

    // ===================== POTONG 4 =====================
    interface PaymentMethod {
        boolean pay(long amount);
    }

    static class EWalletPay implements PaymentMethod {
        @Override
        public boolean pay(long amount) { return amount <= 500_000; }
    }

    static class OrderService {
        private final PaymentMethod paymentMethod;

        OrderService(PaymentMethod paymentMethod) {
            this.paymentMethod = paymentMethod;
        }

        void placeOrder(String orderId, long amount) {
            if (paymentMethod.pay(amount)) {
                System.out.println(orderId + " dibayar");
            }
        }
    }

    // ===================== POTONG 5 =====================
    static final class PriceFormatter {
        private PriceFormatter() { }

        static String format(long rupiah) {
            return "Rp" + String.format(Locale.ROOT, "%,d", rupiah).replace(',', '.');
        }
    }
}
