package shop.notify;

import shop.model.Order;
import shop.util.Rupiah;

public class SmsChannel implements NotificationChannel {
    @Override
    public void send(Order order, long amount) {
        System.out.println("[SMS] " + order.getAddress().getRecipient() + ": pesanan "
                + order.getOrderId() + " sudah dibayar (" + Rupiah.format(amount) + ")");
    }
}