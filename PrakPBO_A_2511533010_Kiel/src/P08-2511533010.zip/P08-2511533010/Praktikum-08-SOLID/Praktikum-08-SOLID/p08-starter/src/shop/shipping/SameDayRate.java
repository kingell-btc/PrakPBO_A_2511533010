package shop.shipping;

public class SameDayRate implements ShippingRate {
    private final long ratePerKg;
    private final long sameDaySurcharge;

    public SameDayRate(long ratePerKg, long sameDaySurcharge) {
        if (ratePerKg < 0 || sameDaySurcharge < 0) {
            throw new IllegalArgumentException("Tarif tidak boleh negatif");
        }
        this.ratePerKg = ratePerKg;
        this.sameDaySurcharge = sameDaySurcharge;
    }

    @Override
    public long calculate(int weightGram) {
        if (weightGram < 0) {
            throw new IllegalArgumentException("Berat tidak boleh negatif");
        }
        return weightGram == 0 ? 0 : ((weightGram + 999L) / 1000L) * ratePerKg + sameDaySurcharge;
    }
}