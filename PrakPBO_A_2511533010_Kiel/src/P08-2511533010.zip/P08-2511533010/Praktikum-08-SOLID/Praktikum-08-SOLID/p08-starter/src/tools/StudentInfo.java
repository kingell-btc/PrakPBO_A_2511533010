package tools;

/** SATU-SATUNYA file di package tools yang boleh Anda ubah. */
public final class StudentInfo {
    private StudentInfo() {
    }

    public static final String NAME = "Heskhiel Suranta Hutauruk";
    public static final String NIM = "2511533010";
    public static final String CLASS_NAME = "C";
}
