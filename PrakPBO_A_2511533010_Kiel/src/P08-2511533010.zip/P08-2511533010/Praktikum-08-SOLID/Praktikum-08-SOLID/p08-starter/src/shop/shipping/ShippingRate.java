package shop.shipping;

public interface ShippingRate {
    long calculate(int weightGram);
}