package shop.shipping;

public class PerKgShippingRate implements ShippingRate {
    private final long ratePerKg;

    public PerKgShippingRate(long ratePerKg) {
        if (ratePerKg < 0) {
            throw new IllegalArgumentException("Tarif per kg tidak boleh negatif");
        }
        this.ratePerKg = ratePerKg;
    }

    @Override
    public long calculate(int weightGram) {
        if (weightGram < 0) {
            throw new IllegalArgumentException("Berat tidak boleh negatif");
        }
        return weightGram == 0 ? 0 : ((weightGram + 999L) / 1000L) * ratePerKg;
    }
}