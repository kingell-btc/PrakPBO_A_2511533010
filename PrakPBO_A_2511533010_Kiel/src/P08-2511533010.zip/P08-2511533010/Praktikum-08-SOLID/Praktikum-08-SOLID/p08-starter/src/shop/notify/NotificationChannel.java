package shop.notify;

import shop.model.Order;

public interface NotificationChannel {
    void send(Order order, long amount);
}