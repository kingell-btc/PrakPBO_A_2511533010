package shop.service;

import java.util.List;
import shop.model.Order;
import shop.notify.NotificationChannel;

public class Notifier {
    private final List<NotificationChannel> channels;

    public Notifier(List<NotificationChannel> channels) {
        this.channels = List.copyOf(channels);
    }

    public void notifyPaid(Order order, long amount) {
        for (NotificationChannel channel : channels) {
            channel.send(order, amount);
        }
    }
}