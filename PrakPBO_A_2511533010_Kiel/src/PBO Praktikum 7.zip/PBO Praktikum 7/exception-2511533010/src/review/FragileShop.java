package review;

import java.io.BufferedReader;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import shop.exception.CatalogLoadException;
import shop.exception.OutOfStockException;
import shop.exception.PaymentFailedException;
import shop.payment.EWalletPayment;
import shop.payment.PaymentMethod;
import shop.service.Inventory;

public final class FragileShop {
    private FragileShop() {
    }

    public static void main(String[] args) {
        try {
            payOrder(new EWalletPayment("DompetKu", 50_000), 85_000);
            System.out.println("Pembayaran selesai.");
        } catch (PaymentFailedException e) {
            System.out.println("Pembayaran gagal: " + e.getMessage());
        }

        Inventory inventory = new Inventory();
        inventory.addStock("KOPI-001", 1);
        System.out.println("Kopi tersedia? " + isInStock(inventory, "KOPI-001"));
        System.out.println(addToCart(inventory, "KOPI-001", "dua"));
        System.out.println(addToCart(inventory, "KOPI-001", "5"));

        try {
            System.out.println("Header: " + readCatalogHeader(Path.of("katalog-lama.csv")));
        } catch (CatalogLoadException e) {
            System.out.println("Katalog gagal dibaca: " + Path.of("katalog-lama.csv")
                    + " | penyebab: " + e.getCause());
        }
    }

    public static void payOrder(PaymentMethod payment, long amount)
            throws PaymentFailedException {
        payment.pay(amount);
    }

    public static boolean isInStock(Inventory inventory, String sku) {
        return inventory.available(sku) > 0;
    }

    public static String readCatalogHeader(Path file) throws CatalogLoadException {
        try (BufferedReader reader = Files.newBufferedReader(file)) {
            return reader.readLine();
        } catch (IOException e) {
            throw new CatalogLoadException("Katalog gagal dibaca: " + file, e);
        }
    }

    public static String addToCart(Inventory inventory, String sku, String quantityText) {
        int quantity;
        try {
            quantity = Integer.parseInt(quantityText);
        } catch (NumberFormatException e) {
            return "Gagal: Jumlah harus berupa angka.";
        }
        if (quantity <= 0) {
            return "Gagal: Jumlah harus lebih dari 0.";
        }
        try {
            inventory.reserve(sku, quantity);
            return "Ditambahkan " + quantity + " x " + sku;
        } catch (OutOfStockException e) {
            return "Gagal: " + e.getMessage();
        }
    }
}