package shop.io;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import shop.model.Product;

public class InvoiceWriter {
    public void write(Path file, List<Product> products, long total) throws IOException {
        List<String> lines = new ArrayList<>();
        for (Product product : products) {
            lines.add(product.getName() + " - Rp" + product.getFinalPrice());
        }
        lines.add("TOTAL Rp" + total);
        Files.write(file, lines, StandardCharsets.UTF_8);
    }
}