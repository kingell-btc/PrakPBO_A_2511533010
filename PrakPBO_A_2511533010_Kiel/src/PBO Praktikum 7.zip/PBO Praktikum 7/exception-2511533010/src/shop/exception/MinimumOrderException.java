package shop.exception;

public class MinimumOrderException extends ShopException {
    private static final long serialVersionUID = 1L;

    private final long orderAmount;
    private final long minimumAmount;

    public MinimumOrderException(long orderAmount, long minimumAmount) {
        super("Minimal belanja Rp" + minimumAmount + ", total belanja Rp" + orderAmount);
        this.orderAmount = orderAmount;
        this.minimumAmount = minimumAmount;
    }

    public long getOrderAmount() { return orderAmount; }
    public long getMinimumAmount() { return minimumAmount; }
}