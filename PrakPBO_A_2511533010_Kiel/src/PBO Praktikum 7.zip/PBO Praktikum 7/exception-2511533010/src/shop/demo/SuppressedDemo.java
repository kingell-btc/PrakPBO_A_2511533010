package shop.demo;

import java.io.IOException;

public class SuppressedDemo {
    public static void main(String[] args) {
        try (FailingResource resource = new FailingResource()) {
            resource.run();
        } catch (IOException e) {
            System.out.println("Exception utama: " + e.getMessage());
            for (Throwable suppressed : e.getSuppressed()) {
                System.out.println("Suppressed: " + suppressed.getMessage());
            }
        }
    }

    private static final class FailingResource implements AutoCloseable {
        void run() throws IOException {
            throw new IOException("kegagalan saat memproses");
        }

        @Override
        public void close() throws IOException {
            throw new IOException("kegagalan saat menutup resource");
        }
    }
}