package shop.app;

import java.util.List;
import shop.StudentInfo;
import shop.model.PhysicalProduct;
import shop.model.Product;
import shop.payment.BankTransferPayment;
import shop.payment.CreditCardPayment;
import shop.payment.EWalletPayment;
import shop.service.CheckoutService;
import shop.service.Inventory;
import shop.shipping.ExpressShipping;
import shop.shipping.RegularShipping;
import shop.shipping.ShippingService;

public final class ScenarioRunner {
    private static final Product COFFEE =
            new PhysicalProduct("KOPI-001", "Kopi Arabika Gayo 250g", 85_000, 300);
    private static final Product RENDANG =
            new PhysicalProduct("RDG-002", "Rendang Kemasan 250g", 120_000, 400);
    private static final Product TEA =
            new PhysicalProduct("TEH-004", "Teh Kayu Aro 100g", 35_000, 150);

    private ScenarioRunner() {
    }

    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        for (Product product : List.of(COFFEE, RENDANG, TEA)) {
            inventory.addStock(product.getSku(), StudentInfo.stockFor(product.getSku()));
        }
        CheckoutService checkout = new CheckoutService(inventory);
        EWalletPayment wallet = new EWalletPayment("DompetKu", StudentInfo.walletBalance());
        ShippingService regular = new RegularShipping();

        run("S1", checkout, List.of(COFFEE, RENDANG), regular, wallet, wallet, inventory);

        BankTransferPayment bank = new BankTransferPayment("Bank Uji");
        bank.setOnline(false);
        run("S2", checkout, List.of(COFFEE, COFFEE, COFFEE), regular, bank, wallet, inventory);
        run("S3", checkout, List.of(RENDANG, RENDANG), regular, wallet, wallet, inventory);
        run("S4", checkout, List.of(COFFEE), new ExpressShipping(),
            new CreditCardPayment("Mahasiswa", 100_000), wallet, inventory);
        run("S5", checkout, List.of(), regular, wallet, wallet, inventory);
        run("S6", checkout, List.of(TEA, TEA), regular, wallet, wallet, inventory);
    }

    private static void run(String name, CheckoutService checkout, List<Product> cart,
            ShippingService shipping, shop.payment.PaymentMethod payment, EWalletPayment wallet,
            Inventory inventory) {
        String result;
        try {
            result = ShopApp.buy(checkout, cart, shipping, payment);
        } catch (IllegalStateException e) {
            result = "[INVALID] " + e.getMessage();
        }
        System.out.println(name + " " + result + " | stok kopi="
                + inventory.available("KOPI-001") + ", rendang="
                + inventory.available("RDG-002") + ", teh="
                + inventory.available("TEH-004") + " | saldo=Rp" + wallet.getBalance());
    }
}