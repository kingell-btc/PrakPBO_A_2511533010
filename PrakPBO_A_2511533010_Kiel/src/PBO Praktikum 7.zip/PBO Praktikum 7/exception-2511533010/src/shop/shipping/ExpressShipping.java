package shop.shipping;

public class ExpressShipping extends ShippingService {
    public ExpressShipping() {
        super("Ekspres");
    }

    @Override
    public long minimumOrder() {
        return 20_000;
    }

    @Override
    protected long ratePerKg() {
        return 18_000;
    }
}
